# 论文3：当前实现与论文方法的一致性审计

审计日期：2026-10-18。源码镜像只读；未修改任何模型文件，未执行CUDA。本文中的行号均指本次读取的镜像。

审计主目录：`/workspace/bright-design-delivery/joint_anchor_fresh_chain_v2/`，下文简称 `CHAIN/`。继承前端目录：`/workspace/bright-design-delivery/bda_benchmark/`，简称 `BDA/`。

## 1. 首要结论

当前可由代码直接支撑的方法主线是：**冻结的光学—SAR像素/区域前端 → 固定Q上的建筑概率双槽 → 冻结父区域检索与带标签案例读取 → 像素、父区域、双槽及Memory联合残差判别**。新增的概率锚定KL属于正在验证的训练候选。

《论文3》以“建筑相容Q + 分区状态内容适配 + 跨事件监督度量排序”为三项主贡献，描述了更早或另一套模型。前两项仍存在于冻结区域前端中，但**当前新链并没有训练监督检索投影**；主方法必须重组，不应只改题目和结果数字。

当前新链只运行D结构的`control/anchor`匹配目标实验，不是同时训练A/B/C/D，更不是5000步全部完成。共同训练前500步后，复制模型、优化器及随机状态，继续到1500步；5000只用于继承学习率调度的总长度。

截至用户最新证据，本轮在500步初始Val450的第323张图前后因路由检查退出；单图重放已通过，但完整阶段尚未通过。因此本轮没有可用于论文主结果的新完成成绩。

## 2. 核实点与源码位置

| 核实点 | 实际实现 | 精确定位 |
|---|---|---|
| 光学与SAR输入 | DamageFormer衍生A1前端含两路编码与融合，光学定位头产生B | `BDA/model/DamageFormer_S8_MICB_DSMIL.py:595` |
| F256已有建筑调制 | `fused_roi=fused_feature*(alpha+(1-alpha)*B)`；当前构造默认alpha=0.1。背景不被完全置零，但已被衰减 | 同文件`:597`–`:604`；`BDA/experiments/damageformer_joint_region_v1/model.py:55` |
| 当前没有MIL实例判断 | A1包装器构造`mil_residual_scale=0`，也不传`bag_specs` | `damageformer_joint_region_v1/model.py:56`；A1文件`:606` |
| Q已有B先验 | 光学描述亲和、空间距离、建筑相容项形成9个邻接中心的softmax；不是按建筑实例划分 | `BDA/experiments/damageformer_srac_transformer_v1/model.py:74`、`:107`–`:151` |
| Q未使用新增SAR cue | 新来源明确构造`QVariantFront(arm='baseline')` | `CHAIN/new_source.py:82` |
| 结构适配仍在父表示中 | B、软归属差异、Q熵进入残差Adapter；T128包括attention pooling、原F均值/标准差、几何 | `srac_transformer_v1/model.py:165`、`:271`、`:401` |
| 全局区域自注意并非必开 | `region_context=False`为默认；应按Q检查点config核对，不能图中默认画成额外全局层 | `srac_transformer_v1/model.py:274`、`:283`、`:330` |
| 联合阶段前端完全冻结 | 新来源载入A1与Q适配器后`front.requires_grad_(False).eval()` | `CHAIN/new_source.py:82`–`:85` |
| 双槽不修改Q | 槽0=`Q*(1-B)`，槽1=`Q*B`；B插值后使用。Q和B均detach | `CHAIN/deps/original/slots.py:42`–`:65` |
| 空槽处理 | 正质量按真实质量除法；零质量除数替为1并保留零值；query有效性mass>0 | `slots.py:87`–`:95`、`:126`–`:135` |
| 软标签与特征同域 | Train GT one-hot先面积缩放，按同一槽路由汇总；255忽略，不复制父标签给两槽 | `slots.py:100`–`:123`；`server_runtime.py:36`–`:40` |
| 新库来源与规模 | 扫描Train2918，按事件×父软标签主类、有界稳定hash抽样；上限3411，每图每类最多2 | `CHAIN/new_members.py:18`–`:37`、`:110`–`:154` |
| 库规模不是固定精确3411 | 代码是容量上限；实际`support_count`和独立图像数由manifest决定 | `new_members.py:144`、`:167`–`:179` |
| 冻结父检索 | 当前key=t128、K=64；C/D使用同样父ID，图内A/B使用同样质心邻居 | `CHAIN/fresh_chain.py:34`–`:38`；`server_runtime.py:349`–`:378` |
| 不学习外部排序 | `prepare()`为no_grad，在训练分类器前产生ID。没有检索投影优化器、SupCon或排序损失 | `server_runtime.py:349`、`:363`–`:366`；`model.py:3` |
| 跨事件排除 | 选ID时传event/image ID，再验证同事件/同图未被选入 | `server_runtime.py:230`–`:239`、`:360`–`:366` |
| 图内参考包含自己 | 依据Q质心平方欧氏距离，active区域自身可作为近邻 | `CHAIN/deps/original/base_runtime.py:73`–`:96` |
| 图内/历史标签来源不同 | 图内槽读同前向native概率；历史槽读Train软标签 | `server_runtime.py:367`–`:378` |
| Reader接收哪些信息 | F256子槽、父T128、槽角色、质量比例、Train软标签；事件/图像ID用于过滤和审计，未嵌入Reader | `CHAIN/deps/original/model.py:36`–`:62`、`:159`–`:166` |
| 每个查询槽看两种支持槽 | Top64父案例展开最多128支持槽，两查询角色拥有同一候选集合，不是建筑槽只看建筑槽 | `model.py:67`–`:88` |
| 不足K使用mask | -1索引和invalid槽mask，缺失上下文为零；不存在可学习的补位支持槽 | `model.py:69`–`:90`；`base_runtime.py:94` |
| 双槽在分类前已汇加 | 各自按对应路由回投，但所有2R槽累加成一个128维slot_grid；Memory也为一个128维memory_grid | `model.py:167`–`:171`；`slots.py:138`–`:150` |
| 最终残差起点 | 输入concat为64像素+128父+128槽+128Memory+4概率=452通道；末层零初始化；logits=log(clamp(grid_probq))+delta | `model.py:47`–`:50`、`:167`–`:175` |
| `grid_probq`不是区域分类头输出 | 同次前向A1低分辨率logits先softmax，再Q均值汇总和同Q回投、resize | `BDA/experiments/damageformer_srac_memory_metric_eval_v2/native.py:79`–`:111` |
| 原目标保留背景 | NLL+Lovász(`classes='present'`)，ignore=255 | `CHAIN/deps/original/base_runtime.py:508`–`:512` |
| KL候选无门控 | `KL(stopgrad(grid_probq)||p_joint)`，每图有效像素均值再图像均值；背景及teacher错误均参与 | `CHAIN/deps/study/anchor.py:1`–`:11`、`:54`–`:75`、`:104`–`:134` |
| KL不是新结构或新数学损失 | 原目标+λKL；KL定位/等级分解用于诊断，不是新增两项损失 | `anchor.py:72`–`:75`、`:135`–`:173`；`engine.py:60`–`:69` |
| 最新实验预算 | D、λ=.1、共同500步、control/anchor到1500，后500步起LR×.2；保留5000 horizon | `fresh_chain.py:70`–`:74`；`deps/study/run.py:187`–`:255`；`deps/helpers/continuation.py:62`–`:76` |
| 当前不是训练覆盖整Train | 建库扫描Train2918；1500步试验使用1500张不重复epoch-zero查询，报告`all_Train2918_visited=False` | `deps/study/run.py:262`、`:298`–`:300` |
| 指标口径 | foreground_miou固定取类1/2/3均值，缺类IoU按0；不是四类mIoU | `CHAIN/deps/original/train.py:125`–`:141` |

**核查边界**：实际V3排序实现由服务器`damageformer_srac_memory_rebuild_v3/core.py`动态导入，本镜像缺少该模块正文；调用界面、no_grad、Top64、key、排除检查已直接验证，`test_selection_v3.py:1`明确标为cosine ranker。论文可暂按“固定父区域相似度检索”写，精确余弦归一化、平局排序公式应在发布前将服务器core.py归档后再最终锁定。本审计不以测试文件替代未读到的运行源码。

## 3. 真实模型的公式与图结构

设像素前端输出已ROI调制的融合特征F_i、建筑概率B_i和native四类概率p_i；冻结局部关联Q_{ir}满足sum_r Q_{ir}=1。Q只在每个像素附近9个区域中心上有非零支撑。

Q生成评分可概括为：

`s_ir = affinity(R_i,R_r)/tau - lambda_s*distance(i,r)^2 + lambda_b*log(B_i*B_r+(1-B_i)*(1-B_r))`，有效邻接中心上softmax并迭代更新中心。

双槽路由：`w_ir0=Q_ir*(1-B_i)`、`w_ir1=Q_ir*B_i`。质量`m_rs=sum_i w_irs`，槽特征`f_rs=sum_i w_irs F_i / m_rs`（m>0）；`rho_rs=m_rs/(m_r0+m_r1)`。同一权重池化Train one-hot标签形成`y_rs`，ignore像素不计标签质量。B不是真值。槽0不要求标签为背景，槽1也不要求某一损毁类别。

槽编码为：`e_rs = GELU(LN(phi_f(f_rs)+phi_t(T_r)+e_role(s)+W_rho rho_rs))`。父T128共享给两个槽，不能把它写成分别重算的两个T128。

父区域选K个ID，展开为两槽。Reader键仅由支持槽编码映射；值由支持槽编码加四类软标签嵌入再映射。四头注意力分别计算两查询槽对所有2K支持槽的响应。角色标签和质量比属于网络输入；事件及图像标识属于合法性过滤，不是网络值向量。

回投：`G_slot(i)=sum_(r,s) w_irs e_rs`、`G_mem(i)=sum_(r,s) w_irs c_rs`；父上下文`G_parent(i)=sum_r Q_ir e_parent,r`。

原概率共享：`p_grid(i)=sum_r Q_ir [sum_j Q_jr p_j / sum_j Q_jr]`，再按实现恢复原分辨率并归一化。不是先平均logits再softmax，也不是对最终D输出再次平滑。

联合输出：`p_joint=softmax(log(max(p_grid,1e-8))+Upsample(h([phi_pixel(F),G_parent,G_slot,G_mem,Downsample(p_grid)])))`。零初始化最后卷积让初始输出近似等于经过floor/归一化后的p_grid；有极小概率floor时应写“经数值稳定处理复现基线”，不要宣称数学上对所有概率绝对相等。

候选训练：`L_original=L_NLL+L_Lovasz-present`；`L_anchor=L_original+0.1 mean_image mean_valid_pixel KL(p_grid||p_joint)`。GT只用于监督及分层诊断/ignore mask，不用于选择teacher正确像素。没有接受或拒绝Memory的开关。

建议框架图的文字顺序：

`光学+SAR → 冻结A1 → {F,B,p_native}`；`光学多尺度 → 冻结结构描述/Q → 父F256/T128`；`Q+B → 双槽摘要`；`父T128 → 合法Train父Top64 → 2K槽及软标签 → Reader`；`原Q父回投 + 双槽同路由回投合并 + Memory同路由回投合并 + 像素路径 + grid_probq → 残差联合头`。训练图另用虚线画冻结p_grid到KL，标“训练候选”。

## 4. 《论文3》哪些段落必须改

段落编号来自`source_extract/paper3_text.txt`，不是Word页面号。

| 原段落/图 | 问题 | 建议 |
|---|---|---|
| P0001、P0007、P0009、P0024、P0027、P0030 | 主张跨事件类别监督学习检索投影；当前没有该训练路径 | 改成建筑概率双槽组织、跨事件合法案例读取、概率基线联合残差判别 |
| P0032、P0047–P0063/图2 | 结构条件Adapter与父T128描述大体对应继承前端，但遗漏新增双槽 | 保留为基础前端/父上下文，压缩篇幅；图2中心改为Q后分流、标签同权汇总、质量与空槽 |
| P0033、P0080、P0086/图3 | 将事件元数据嵌入Reader、可学习缺失支持槽、K=8写进方法 | 删除事件embedding和学习补位；改成Top64父→最多128槽，mask无效支持 |
| P0066–P0078 | 纯度≥.8的跨事件SupCon、恒等初始化投影、温度.1均非当前链 | 整节替换为Train案例构建、固定父检索、Reader；若未来重新引入，单列未实现扩展 |
| P0094–P0099 | 四阶段训练包含检索投影；像素分类权重复制初始化与当前log概率残差不同 | 改为冻结来源→建父库→建槽值→联合头训练；最终log概率残差及零末层初始化；KL单列候选 |
| P0099 | 声称仅Reader和联合头可训练漏掉region_encoder/slot/pixel projections等 | 逐项列可训练投影、槽编码、Reader、联合头；冻结的是A1/Q/T父原始生成器和库 |
| 表1/表2、P0108、P0198 | 69.64四类Test和54.04事件宏均值来自旧模型，未绑定当前模型权重与数据协议 | 新稿留空待测；若保留只能明确归为旧版本历史记录，不能作为当前soft+Memory结果 |
| 表4–7 | 重点是旧Q开关/条件Adapter/监督排序，与新主线不一致 | 主表转为单槽/空间双槽/soft双槽×图内/Memory；标签与随机支持；融合/冻结基线；KL候选与多种子 |
| 图1 | 缺两个槽、概率共享、log概率残差、冻结范围 | 按本报告第3节修改模块与箭头，不需重画底层骨干 |
| 图3 | 监督投影/元数据value不符 | 改成冻结父key选择与可训练Reader注意力两级，避免把内部attention称作外部learned ranker |
| 图5–8 | 旧Ours可视化不能自动代表新版本D/anchor | 保留原图到历史附录或换成当前同权重预测；标出checkpoint、事件、裁窗、像素混淆与检索轨迹 |

这些并不意味着旧方法从未存在或旧数据虚假；只说明**它们不能在缺少对应运行来源时归给当前这版代码**。

## 5. 三点贡献可以怎样写

建议将“创新点”限定成可核实的方法设计贡献，不把通用部件首次化。

1. **建筑概率引导的区域双槽证据组织。** 在冻结软区域归属内，用互补连续权重组织偏建筑与偏背景内容，保持父区域上下文，并使特征、支持软标签与回投使用对应权重。重点是减少混合证据在单一摘要中的耦合；不宣称实例分割、严格建筑内部超像素、或已证明两槽互补。
2. **受来源约束的历史案例联合读取。** 在Train中构建带标签区域案例，父级选择与槽级读取分离；排除同图/同事件，Reader联合使用槽外观、父上下文、角色、质量及软标签。核心问题是历史监督能否补充图内上下文，需随机合法支持、无标签、图内同容量对照。不能主张新的监督检索算法。
3. **保留像素与概率基线的联合修正及稳定性检验。** 由像素、父区域、双槽和案例上下文预测对grid_probq的残差；在相同初始化与数据流下，检验输出KL是否减轻误改。KL为标准蒸馏/一致性形式，应引用既有方法。当前可作为“提出并检验的训练策略”，最终摘要只能在完整配对结果后写“改善”。如果anchor无效，将第3点写为联合读出与机制验证，而不是硬凑新损失创新。

创新程度：单独的软加权池化、cross-attention、带标签Memory、残差和KL都已有广泛先例。可争取的是**光学—SAR建筑损毁场景下明确问题驱动的组合机制与严格证据**，属于方法组合/应用适配，尚无依据称基础架构级突破。若双槽相对空间双槽仅极小收益且未复现，必须降低贡献措辞，不能通过重新命名提升新颖性。

## 6. 最少需要的因果与效能证据

- 同源冻结`grid_probq`、匹配单槽联合头、空间双槽、soft双槽：区分区域读出、容量与B语义路由。
- A/B/C/D统一新库/前端/训练预算配对：B−A和D−C验证soft，C−A和D−B验证Memory；交互项`D−C−B+A`只表示这一设置的交互。
- Memory匹配重训：合法随机父支持、检索父支持、去Train软标签；固定推理时打乱仅作为依赖诊断。
- 当前control/anchor：相同500步、优化器/RNG/图序、.2学习率，终点1500。λ与步数预先固定，不能Test选型。
- 真实槽内容：混合区与纯区分别报F余弦相似度、软标签差异、槽质量/有效像素数；仅相似并不能判错。
- 支持覆盖：实际父案例数/独立图像/事件数、重复率、Damaged支持质量、Intact困难负例；64父案例不能当128独立案例。
- 完整末步Val、各类IoU/precision/recall、事件、逐像素救回与误改、至少3配对种子；Test只用于冻结方案的最终评估。
- 图示必须来自已记录权重：Q边界+两槽热图、相同查询的真实支持区域/标签/来源、两槽Reader响应、基线→D→anchor预测错误变化，包含失败案例。

## 7. 写作中必须保留的边界

Q是稀疏软关联，不保证连通与建筑实例身份。背景槽包含已有前端抑制后的F，不是恢复原始楼外SAR。跨事件支持排除不等于未见事件泛化。冻结库不是动态记忆更新。Reader注意力不是可解释因果归因。全局或事件mIoU须说明类别平均规则。500步中间正向结果与正式终点负向结果应同时保留；新的重建库与历史成员不一致，不能冒充历史训练轨迹续跑。
