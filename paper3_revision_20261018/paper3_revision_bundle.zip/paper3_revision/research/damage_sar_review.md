# 光学—SAR建筑损毁文献与代码核验（2026-10-18）

核验范围：作者公开GitHub仓库、BRIGHT官方仓库与固定提交源码。arXiv、IEEE、Crossref和CVF多数请求在本环境返回403，不能宣称已逐篇阅读全文。`damage_sar_refs.json`记录14个条目（13篇相关文献+1个代码软件条目），每个条目给出实际核验来源，未核实的DOI留空。未把用户提供的竞赛介绍直接当成论文原文。

## 1. DamageFormer 与 BRIGHT 的关系

BRIGHT官方当前 `bda_benchmark/model/DamageFormer.py` 文件首部引用：Hongruixuan Chen, Edoardo Nemni, Sofia Vallecorsa, Xi Li, Chen Wu, Lars Bromley. *Dual-Tasks Siamese Transformer Framework for Building Damage Assessment*. IGARSS 2022, pp.1600–1603。

因此应分开引用：

- DamageFormer方法来源：上述IGARSS2022论文。
- 光学—SAR任务、BRIGHT数据划分与本项目所用实现：Chen等BRIGHT论文，ESSD 2025，DOI 10.5194/essd-17-6217-2025，以及官方代码版本。

官方BRIGHT代码为多模态任务使用两个Swin编码器；定位、双模态编码、像素融合应表述为继承基础模型的组成，不作为本文新发明。当前用户的A1也不是任意官方checkpoint，应在实验设置注明具体冻结前端来源、版本与训练数据。

参考入口：
- https://github.com/ChenHongruixuan/BRIGHT/blob/master/bda_benchmark/model/DamageFormer.py
- https://github.com/ChenHongruixuan/BRIGHT/blob/master/README.md

## 2. 冠军：Building-Guided Pseudo-Label Learning

作者公开仓库提供正式BibTeX：Jiepan Li, He Huang, Yu Sheng, Yujun Guo, Wei He，IGARSS2025，pp.228–232，DOI 10.1109/IGARSS55030.2025.11243835。作者README明确称其为Track2冠军方案。

公开范围已核对：BuildingExtraction、ChangeDetection两目录；训练、伪标签训练、推理脚本存在。README说明PVT-v2-b2/b3/b4定位网络、六模型训练、模型融合与TTA、连通区域合并后处理。变化检测由其UABCD工作调整而来，README引用 *Overcoming the uncertainty challenges in detecting building changes from remote sensing images*；脚本变量也有UACD命名，两者不能单凭简称推定为不同新模型。

关键数据协议：README明确使用测试集预测概率生成伪标签，并与Hawaii-wildfire真实训练标签转换的one-hot分布混合，用于伪标签微调。这是目标域/测试图像适配，不等于冻结模型直接推理的标准ML协议。

代码细节纠正：
- `BuildingExtraction/train_pseudo_label.py` 函数默认不确定性熵阈值为0.3。
- `ChangeDetection/train_pseudo_label.py` 默认阈值为0.2；主函数调用没有覆盖该默认值。
- 熵由当前预测prob计算；低熵位置采用伪标签argmax的CE，高熵位置采用KL至已有概率图，KL系数默认0.5。

因此，不能在论文中笼统写“该方法两个阶段统一熵阈值0.3”，也不能将它们的伪标签训练记作本文已实现步骤。对当前冻结前端双槽Memory最直接可借鉴的是：建筑概率应作为信息组织先验，及需要报告定位先验错误的传播。是否加入目标域伪标签属于独立协议/实验，当前不建议纳入主线。

代码：https://github.com/Henryjiepanli/Building-Guided-Pseudo-Label-Learning-for-Cross-Modal-Building-Damage-Mapping

## 3. 亚军：DF2025公开代码

BRIGHT官方 `README_DFC25.md` 指向 https://github.com/zxqyiyang/DF2025 为第二名代码。已下载并核对固定提交 `777b0e3ed6b96de31ef8acd6176f8e1c8e03bda5`；仓库无顶层README。用户提供论文名 *Building Damage Mapping through Heterogeneous Feature Consistency and Knowledge Integration* 尚未核验完整作者与DOI，因此本次作为软件文献列出，不伪造论文书目。

已核实实现：
- `STMambaBDA_DFv4.py:401–431` 在训练时使用post_label==1的Intact掩膜，作用于后两个尺度的光学/SAR编码特征，计算掩膜MSE并作有效区域归一化。
- `train_BD.py:85` 额外Lovász调用处于注释状态。
- `config/STMambaBDA.py:78–80` criterion1与criterion2使用OhemCELoss，阈值0.7；不能根据二手介绍将α=0.75的CE+Lovász称为当前公开源码设置。
- `train_BRIGHT_Fine-tune_second.sh:1` 明确注明“fine-tune using all test dataset”。

对当前框架的意义：完好区一致性可作为独立研究候选，但目前前端被冻结，直接对两组冻结特征添加MSE不会改变编码器或Memory Reader；必须有相应可训练投影/编码器及梯度路径，且需控制配准误差与跨模态差异。对象投票需可靠建筑对象范围，当前Q软区域/两个槽没有实例身份，不能直接宣称实现了对象级损毁一致性。

## 4. 指标与数据协议不能混用

BRIGHT官方DFC25文档明确：9个事件用于训练/验证，Noto-Earthquake-2024和Marshall-Wildfire-2021作为未见测试事件。用户当前标准ML Train2918/Val450/Test878是另一协议；竞赛54.28%、50.81%不能与约62%的三类前景mIoU直接排名。还须核对四类均值vs前景三类均值、逐像素累计vs逐事件宏平均、外部xBD训练、目标域伪标签、集成和TTA。

论文主表应固定同一数据划分、同一模型选择规则和指标定义；跨协议相关工作仅在讨论中介绍机制。不要把旧文69.64%的四类mIoU或14事件宏平均54.04%移植到新双槽/Memory/anchor模型。

## 5. 三条创新点的可辩护边界

1. **建筑先验驱动的父区域双槽组织**：在固定Q后通过Q×B与Q×(1−B)组织两份内容，保留父区域与像素路径。区别应落实到槽权重、标签对应、空槽质量和回投规则；前景引导、区域聚合本身在FarSeg、BIT、超像素方法已有基础，不宜宣称“首次引入建筑先验”。
2. **区域案例内容与像素判断的联合建模**：固定父key检索合法Train支持，读取案例特征、双槽软标签/几何等，然后与查询像素区域联合判断。创新点在具体案例内容组织和匹配可检验性，不在普通TopK/CrossAttention；当前未训练检索排序器时不能称“跨事件类别监督排序学习”。
3. **基于冻结预测的受约束残差学习与可解释验证**：以grid_probq作为基础分布，增加可训练残差并用KL anchor考查有害改判。KL/蒸馏本身属已有机制，当前仅为候选，需要配对分支、多种子与救回/误伤证据后才能升级为正式核心贡献。若anchor无收益，第三条应写“受控验证与误差归因”，不要硬包装成第三个新算法模块。

目前更准确的创新程度描述：基于既有前端、区域聚合和案例记忆的**任务导向方法组合与机制细化**。创新强度由能否证明双槽互补、Memory增量、受约束残差保留有益纠错来决定；不能依靠改名或复杂框图提高原创性。

## 6. 与新稿方法及图修改有关的核验意见

- 基础前端注明“冻结DamageFormer/A1”，定位概率B是预测而非GT。
- Q画为固定软分配到父区域；Q之后画两槽。不要画成两套独立实例检测或重新优化Q。
- 父key检索与双槽value读取分开：Top64父案例不是128个独立案例；Train软标签不进入查询key或Val排序。
- 当前代码若把两槽先加权合并再分类，图应如实画汇合。独立双槽到最终头仍是候选，不能画成已经实现。
- 训练损失图中分清监督NLL/Lovász与KL anchor；anchor箭头来自停止梯度的grid_probq。它是全输出约束，非建筑掩膜硬门控或Memory拒绝门。
- 不画冠军伪标签适配、亚军Intact MSE、外部xBD补楼、对象投票为本文已经实现模块。
- 报告原D5000低于冻结基线的事实；新chain当前Val重放数值异常未定位，不可写为实验完成或有效新结果。
