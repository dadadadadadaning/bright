# 论文 3：中文 LaTeX 学术论文版

本文档已将《论文3_按当前代码重写.docx》整理为可编辑、可编译的 LaTeX 项目。

选用 CTeX 的 `ctexart` 文档类，采用 A4 单栏中文学术论文版式。用户没有指定投稿期刊，因此本项目是通用中文学术稿，不是某家期刊的官方投稿格式。模板来源见 `TEMPLATE_SOURCES.md`。

## 一、直接在 Overleaf 使用

1. 新建项目，选择上传 ZIP，将交付的源码压缩包上传。
2. 主文档选择 `main.tex`。
3. 编译器选择 **XeLaTeX**；建议使用较新的 TeX Live。
4. 点击重新编译。正文引用和公式编号需要两轮，Overleaf 会自动处理。

此项目没有使用 BibTeX/Biber，参考文献保存在 `references.tex`，无需另设文献编译器。

## 二、在本地编译

建议安装完整的 TeX Live 或带中文支持的 MiKTeX，确保存在 `ctex`、`xeCJK`、`zhnumber`、`fontspec`、`tcolorbox`、`tabularx` 等宏包。

```bash
latexmk -xelatex main.tex
```

也可以执行两次：

```bash
xelatex main.tex
xelatex main.tex
```

输出文件为 `main.pdf`。中文字体优先使用 TeX Live 自带的 Fandol；若不存在，则使用 Noto Serif/Sans CJK SC。交付 PDF 已使用 Noto 字体实际编译，字体已嵌入。

## 三、从哪里修改

| 文件 | 内容 |
| --- | --- |
| `main.tex` | 主入口，文档顺序、修订说明显示开关 |
| `metadata.tex` | 标题、作者、单位/基金信息、页眉短标题 |
| `paperstyle.sty` | 字体、页边距、章节、公式、表格、图片占位框等版式设置 |
| `sections/abstract.tex` | 摘要、关键词 |
| `sections/01_introduction.tex` | 引言 |
| `sections/02_related_work.tex` | 相关工作 |
| `sections/03_method.tex` | 方法 |
| `sections/04_experiments.tex` | 实验设置与结果组织，全部 8 张表 |
| `sections/05_discussion.tex` | 讨论 |
| `sections/06_conclusion.tex` | 结论 |
| `sections/revision_note.tex` | 原稿的修订说明，默认显示 |
| `references.tex` | 50 条参考文献及原稿链接 |
| `figures/` | 后续正式图片放置目录 |
| `latexmkrc` | XeLaTeX 自动编译配置 |
| `CONVERSION_NOTES.md` | 转换清单、保留事项与检查记录 |

## 四、插入图片

原 DOCX 没有嵌入图片，只有图 1—图 10 的文字图位。因此 PDF 当前显示占位框及原图注，没有生成或虚构实验图。

把正式图片命名为 `fig01.pdf`、`fig02.pdf` …… `fig10.pdf`，放进 `figures/` 后重新编译，占位框会自动替换。也支持同名 `.png` 和 `.jpg`，优先级依次为 PDF、PNG、JPG。

每个图位使用：

```tex
\paperfigure{01}{图注内容}
```

图宽默认是正文宽度的 94%，可在 `paperstyle.sty` 的 `\paperfigure` 定义中修改。图注保留了原稿中的制图要求，完成正式图片后可再整理为最终投稿图注。

## 五、公式、表格与引用

- 14 个编号公式均为可编辑 LaTeX 数学表达式，不是截图。
- 长公式采用 `aligned` 分行；公式编号由 LaTeX 自动生成。
- 行内公式来自 Word OMML 转换，数学含义保持原稿。
- 8 张表均使用 `booktabs` 三线表与 `tabularx` 自动换行，没有将整表缩放成图片。
- 保留原表号：表 1、2(a)、2(b)、3、4、5、6、7。
- 正文引文转换为 `\cite{ref1}` 等，可点击跳转。新增文献时，在 `references.tex` 添加新的 `\bibitem{...}` 并引用相同键。
- 原 Word 通过域代码保存的 50 个参考文献链接已恢复为 `\href`，没有擅自替换目标网址或补造书目信息。

## 六、原稿中的待补内容

作者、单位和基金信息仍为占位。所有“待测”、候选方案、拟补实验、摘要/结论填数提示均保留；未将聊天中的最新训练状态或未验证成绩写进论文。

原稿修订说明默认显示在首页。完成正式修订后，可以将 `main.tex` 中的：

```tex
\draftnotestrue
```

改为：

```tex
\draftnotesfalse
```

该开关仅隐藏首页修订说明，不会自动删除正文中的待填提示、图位或实验限制。正文内容需要作者依据实际实验结果更新。
