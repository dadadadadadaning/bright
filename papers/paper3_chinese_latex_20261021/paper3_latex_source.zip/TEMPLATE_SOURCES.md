# 模板选择与官方来源

## 本次采用：CTeX / ctexart

- 官方仓库：https://github.com/CTeX-org/ctex-kit
- 本次本地编译所用的稳定源码标签：https://github.com/CTeX-org/ctex-kit/tree/ctex-v2.5.10
- 官方 README 明确给出 `\documentclass{ctexart}` 的使用方式，并推荐 XeLaTeX 或 LuaLaTeX。
- CTeX 的许可为 LaTeX Project Public License（LPPL）1.3c 或更高。

选择原因：原稿是中文研究论文，包含较长公式、8 张表格和 50 条参考文献，且没有指定期刊。`ctexart` 提供中文字体、标点和标题支持，A4 单栏可以保持表格和公式的可读性，后续也方便调整为目标期刊版式。

本项目的 `paperstyle.sty` 是为该稿编写的自定义版式，不是 CTeX 官方期刊模板；底层使用官方 CTeX 文档类。主交付 ZIP 不重新分发 CTeX 宏包源码，编译时由 Overleaf/TeX Live/MiKTeX 提供。

## 已查阅的另一方案：ElegantPaper

- 官方仓库：https://github.com/ElegantLaTeX/ElegantPaper
- README：https://github.com/ElegantLaTeX/ElegantPaper/blob/master/README.md
- 许可：LPPL 1.3c 或更高。

该项目定位为工作论文模板，其文档对经济学写作有较多面向性说明。本次采用更通用的 `ctexart`，便于保留原论文的研究结构和图表安排。

以上链接是模板/文档类来源，不代表论文已经满足某个期刊的投稿要求。参考文献的论文链接另保存在 `references.tex`，沿用上传稿。
