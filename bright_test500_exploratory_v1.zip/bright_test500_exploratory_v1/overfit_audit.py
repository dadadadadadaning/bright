#!/usr/bin/env python3
"""Read-only audit of an existing Q-rebased A/B/C/D Val450 training run.

This script never loads weights or touches Train/Val/Test images. It only reads
the JSON reports written by the released Q-rebased four-arm trainer.
"""

from __future__ import annotations

import argparse
import json
import math
import statistics
from pathlib import Path
from typing import Any


FORMAT = "SRAC_SOFT_MEMORY_Q_REBASED_V1"
ARMS = ("grid_probq", "a", "b", "c", "d")
TRAIN_ARMS = ARMS[1:]
STEPS = (500, 1500, 5000)
WINDOWS = ((1, 500), (501, 1000), (1001, 1500), (4501, 5000))
CLASSES = ("背景", "完好", "受损", "毁坏")


def read_object(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON 根节点不是对象：{path}")
    return value


def val_path(root: Path, step: int) -> Path:
    return root / "train" / ("final_val" if step == 5000 else f"val_step_{step:06d}") / "result.json"


def checked_metric(metric: Any, where: str) -> dict[str, Any]:
    if not isinstance(metric, dict):
        raise ValueError(f"{where} 缺少指标")
    iou = metric.get("iou")
    if not isinstance(iou, list) or len(iou) != 4:
        raise ValueError(f"{where} 没有四类 IoU")
    for value in iou:
        if value is not None and (isinstance(value, bool) or not isinstance(value, (int, float))
                                  or not math.isfinite(value) or not 0 <= value <= 1):
            raise ValueError(f"{where} 含无效 IoU")
    fg = metric.get("foreground_miou")
    if isinstance(fg, bool) or not isinstance(fg, (float, int)) or not math.isfinite(fg):
        raise ValueError(f"{where} 缺少有限的前景 mIoU")
    expected = sum(value or 0.0 for value in iou[1:]) / 3
    if not math.isclose(fg, expected, rel_tol=0, abs_tol=1e-6):
        raise ValueError(f"{where} 的前景 mIoU 与四类 IoU 不一致")
    target = metric.get("target_pixels")
    if target is not None and (not isinstance(target, list) or len(target) != 4
                               or any(type(x) is not int or x < 0 for x in target)):
        raise ValueError(f"{where} 的 target_pixels 不合法")
    return metric


def load_val(root: Path, step: int) -> dict[str, Any]:
    path = val_path(root, step)
    result = read_object(path)
    if result.get("format") != FORMAT or result.get("phase") != "evaluation":
        raise ValueError(f"{path}: 格式或阶段不匹配")
    for field, expected in (("image_count", 450), ("execution_complete", True),
                            ("whole_val450_processed", True), ("smoke", False),
                            ("test_accessed", False)):
        if result.get(field) != expected:
            raise ValueError(f"{path}: {field}={result.get(field)!r}，预期 {expected!r}")
    if step == 5000:
        for field in ("primary_endpoint", "full_validation_evidence", "saved_predictions_reopened"):
            if result.get(field) is not True:
                raise ValueError(f"{path}: 正式末步 {field} 未通过")
        if result.get("final_integrity_pending") is not False:
            raise ValueError(f"{path}: 末步终检仍待完成")
    elif result.get("full_validation_evidence") is not False:
        raise ValueError(f"{path}: 中间评估被错误标成正式末步")
    metrics = result.get("metrics")
    events = result.get("per_event")
    if not isinstance(metrics, dict) or not isinstance(events, dict):
        raise ValueError(f"{path}: 缺少总指标或逐事件指标")
    for arm in ARMS:
        checked_metric(metrics.get(arm), f"{step} 步 {arm}")
    for event, rows in events.items():
        if not isinstance(rows, dict):
            raise ValueError(f"{step} 步事件 {event} 缺少各组指标")
        for arm in ARMS:
            checked_metric(rows.get(arm), f"{step} 步事件 {event} {arm}")
    return result


def load_loss_windows(path: Path) -> tuple[dict[tuple[int, int], dict[str, Any]], list[str]]:
    warnings = []
    if not path.is_file():
        return {}, [f"训练日志不存在：{path}"]
    rows: dict[int, dict[str, Any]] = {}
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            warnings.append(f"训练日志第 {number} 行不是完整 JSON，已跳过")
            continue
        if not isinstance(row, dict):
            warnings.append(f"训练日志第 {number} 行不是对象，已跳过")
            continue
        step = row.get("step")
        if type(step) is not int or not 1 <= step <= 5000:
            warnings.append(f"训练日志第 {number} 行的 step 不合法，已跳过")
            continue
        if step in rows:
            warnings.append(f"训练日志的 step={step} 重复，保留首次记录")
            continue
        rows[step] = row
    windows: dict[tuple[int, int], dict[str, Any]] = {}
    for lo, hi in WINDOWS:
        available = [rows[step] for step in range(lo, hi + 1) if step in rows]
        record: dict[str, Any] = {"count": len(available), "arms": {}}
        if len(available) < hi - lo + 1:
            warnings.append(f"训练损失 {lo}–{hi} 步只找到 {len(available)}/{hi-lo+1} 行")
        lrs = [float(row["lr"]) for row in available
               if isinstance(row.get("lr"), (int, float)) and not isinstance(row["lr"], bool)
               and math.isfinite(row["lr"])]
        record["lr_mean"] = statistics.mean(lrs) if lrs else None
        record["lr_last"] = lrs[-1] if lrs else None
        for arm in TRAIN_ARMS:
            losses = []
            for row in available:
                head = row.get("heads")
                item = head.get(arm) if isinstance(head, dict) else None
                value = item.get("loss") if isinstance(item, dict) else None
                if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value):
                    losses.append(float(value))
            record["arms"][arm] = {"count": len(losses), "mean": statistics.mean(losses) if losses else None,
                                   "median": statistics.median(losses) if losses else None}
            if len(losses) < len(available):
                warnings.append(f"训练损失 {lo}–{hi} 步 {arm} 只找到 {len(losses)}/{len(available)} 个有效值")
        windows[(lo, hi)] = record
    return windows, warnings


def audit(root: Path) -> dict[str, Any]:
    warnings = []
    formal = False
    try:
        state = read_object(root / "workflow_state.json")
        summary = read_object(root / "train" / "summary.json")
        formal = all(state.get(key) is True for key in ("complete", "training_complete", "full_validation_evidence"))
        formal &= all(summary.get(key) is True for key in ("complete", "training_complete", "full_validation_evidence"))
        updates = summary.get("updates_per_arm", {})
        formal &= isinstance(updates, dict) and all(updates.get(arm) == 5000 for arm in TRAIN_ARMS)
        formal &= state.get("format") == FORMAT and summary.get("format") == FORMAT
        if not formal:
            warnings.append("流水线或四组末步终检未确认完成；不能将 5000 步视为正式结果")
    except (OSError, ValueError) as exc:
        warnings.append(f"无法确认正式训练状态：{exc}")
    val = {}
    for step in STEPS:
        try:
            val[step] = load_val(root, step)
        except (OSError, ValueError) as exc:
            warnings.append(f"{step} 步 Val450 不可用：{exc}")
    if 5000 not in val:
        formal = False
    if 500 in val and 5000 in val:
        old_events, new_events = val[500]["per_event"], val[5000]["per_event"]
        if set(old_events) != set(new_events):
            warnings.append("500 与 5000 步的事件集合不同；逐事件比较已跳过")
    windows, log_warnings = load_loss_windows(root / "train" / "train.jsonl")
    warnings.extend(log_warnings)
    return {"formal": formal, "val": val, "loss_windows": windows, "warnings": warnings}


def pct(value: Any) -> str:
    return "—" if value is None else f"{100*value:.4f}"


def pp(value: Any) -> str:
    return "—" if value is None else f"{100*value:+.4f}"


def class_score(metric: dict[str, Any], field: str, class_index: int) -> float | None:
    values = metric.get(field)
    if not isinstance(values, list) or len(values) != 4:
        return None
    value = values[class_index]
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        return None
    return float(value)


def transition_count(transition: Any, field: str, class_index: int | None = None) -> int | None:
    if not isinstance(transition, dict):
        return None
    value = transition.get(field)
    if class_index is not None:
        if not isinstance(value, list) or len(value) != 4:
            return None
        value = value[class_index]
    return value if type(value) is int and value >= 0 else None


def render(root: Path, report: dict[str, Any]) -> str:
    val = report["val"]
    lines = [f"结果目录：{root}",
             "证据状态：" + ("5000 步为正式 Val450 末步；500/1500 步为中间 Val450" if report["formal"]
                             else "正式终检未确认，以下仅供排查"),
             "前景 mIoU 是完好／受损／毁坏三类 IoU 的平均，数值单位 %；差值单位百分点。",
             "", "分类别 Val450 IoU：", "步数  组别       背景     完好     受损     毁坏   前景mIoU"]
    for step in STEPS:
        if step not in val:
            lines.append(f"{step:<5} 缺少可用报告")
            continue
        for arm in ARMS:
            metric = val[step]["metrics"][arm]
            cells = " ".join(f"{pct(x):>8}" for x in metric["iou"])
            lines.append(f"{step:<5} {arm:<10} {cells} {pct(metric['foreground_miou']):>10}")
    lines += ["", "D 的分类别差值（同一步同一份 Val450）：",
              "步数  对照        背景     完好     受损     毁坏   前景mIoU"]
    for step in STEPS:
        if step not in val:
            continue
        metrics = val[step]["metrics"]
        for baseline in ("grid_probq", "b"):
            d, other = metrics["d"], metrics[baseline]
            cells = " ".join(f"{pp(x-y) if x is not None and y is not None else '—':>8}"
                             for x, y in zip(d["iou"], other["iou"]))
            lines.append(f"{step:<5} D−{baseline:<10} {cells} {pp(d['foreground_miou']-other['foreground_miou']):>10}")
    lines += ["", "受损类（Damaged）的精确率／召回率与 D 的像素转移：",
              "步数  路径          精确率%  召回率%  D救回受损  D误伤受损  原正确完好→受损  原误判完好→受损纠正"]
    for step in STEPS:
        if step not in val:
            continue
        metrics = val[step]["metrics"]
        transitions = val[step].get("transitions")
        transition = transitions.get("d") if isinstance(transitions, dict) else None
        rescue = transition_count(transition, "rescued_by_gt_class", 2)
        harm = transition_count(transition, "harmed_by_gt_class", 2)
        intact_harm = transition_count(transition, "correct_intact_changed_to_damaged")
        damaged_rescue = transition_count(transition, "damaged_previously_intact_now_damaged")
        for arm in ("grid_probq", "d"):
            metric = metrics[arm]
            precision = class_score(metric, "precision", 2)
            recall = class_score(metric, "recall", 2)
            extras = (rescue, harm, intact_harm, damaged_rescue) if arm == "d" else (None,) * 4
            lines.append(f"{step:<5} {arm:<12} {pct(precision):>8} {pct(recall):>8} " +
                         " ".join(f"{value:>12}" if value is not None else f"{'—':>12}" for value in extras))
    if 500 in val and 5000 in val and set(val[500]["per_event"]) == set(val[5000]["per_event"]):
        old, new = val[500]["per_event"], val[5000]["per_event"]
        falls = []
        damaged = []
        for event in old:
            earlier, later = old[event]["d"], new[event]["d"]
            delta = later["foreground_miou"] - earlier["foreground_miou"]
            falls.append((delta, event))
            support_old, support_new = earlier.get("target_pixels"), later.get("target_pixels")
            if support_old is not None and support_new is not None and support_old != support_new:
                report["warnings"].append(f"{event} 的 500 与 5000 步真值像素计数不同；受损事件比较已跳过")
                continue
            if support_old is not None and support_old[2] > 0 and earlier["iou"][2] is not None and later["iou"][2] is not None:
                damaged.append((later["iou"][2] - earlier["iou"][2], event, support_old[2]))
        lines += ["", "D 在 500→5000 步下降最多的事件（事件级前景 mIoU 差值，仅用于定位；不能跨事件平均）："]
        for delta, event in sorted(falls)[:5]:
            lines.append(f"  {event}: {pp(delta)}")
        lines.append("D 的受损 IoU 下降最多的事件（括号内为该事件真值受损像素数）：")
        for delta, event, count in sorted(damaged)[:5]:
            lines.append(f"  {event}: {pp(delta)}（{count} 像素）")
        if not damaged:
            lines.append("  没有可比较且含受损真值的事件")
    lines += ["", "训练日志 loss（每组每窗口的算术平均 / 中位数；不是固定 Train 集评估）：",
              "步数窗口     组别    行数   loss平均   loss中位数      LR平均"]
    for window, record in report["loss_windows"].items():
        for arm in TRAIN_ARMS:
            data = record["arms"][arm]
            mean = f"{data['mean']:.6f}" if data["mean"] is not None else "—"
            median = f"{data['median']:.6f}" if data["median"] is not None else "—"
            lr = f"{record['lr_mean']:.3g}" if record["lr_mean"] is not None else "—"
            lines.append(f"{window[0]:4}–{window[1]:<4}  {arm:<5} {data['count']:5}/{window[1]-window[0]+1:<3} {mean:>11} {median:>12} {lr:>12}")
    lines += ["", "解释边界：训练 loss 的不同窗口使用不同图像／裁剪且学习率变化，"
              "即使 loss 下降、Val IoU 下降，也只与过拟合相容，不能单凭此表证明。",
              "进一步验证应在同一组固定 Train 子集与 Val450 上，用 500/1500/5000 的检查点计算同定义的 loss、"
              "分类别指标与 Train−Val 差距，再用预先固定的短训练／早停规则重复种子。",
              "Test878 可作一次探索性外部检查，不能用多次 Test 挑检查点；本轮正式 Val 结果仍是 5000 步。",
              "该脚本只读本地报告，不读取图像、权重或 Test。"]
    if report["warnings"]:
        lines += ["", "缺失／异常：", *("  - " + value for value in report["warnings"])]
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--train-root", type=Path, required=True, help="四组 run_* 根目录")
    args = parser.parse_args()
    root = args.train_root.expanduser().resolve()
    if not root.is_dir():
        parser.error(f"目录不存在：{root}")
    report = audit(root)
    print(render(root, report))
    return 0 if report["formal"] and all(step in report["val"] for step in STEPS) else 2


if __name__ == "__main__":
    raise SystemExit(main())
