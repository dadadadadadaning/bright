"""Pure protocol contracts. No BRIGHT data, CUDA, or actual Torch loading."""
from __future__ import annotations

import importlib.util
from pathlib import Path
import sys
import types
import unittest
from unittest import mock


# The cloud packaging workspace need not contain the research server's Torch.
# The contracts below use only parser, selection, metric comparison and ordering.
try:
    import torch  # noqa: F401
except ImportError:
    sys.modules["torch"] = types.ModuleType("torch")

MODULE_PATH = Path(__file__).with_name("test500.py")
SPEC = importlib.util.spec_from_file_location("test500", MODULE_PATH)
candidate = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(candidate)


def metric(foreground, damaged=None):
    return {"foreground_miou": foreground,
            "iou": [0.96, 0.76, foreground if damaged is None else damaged, 0.65]}


class ExploratoryTest500Contracts(unittest.TestCase):
    def test_val500_selects_d_and_marks_posthoc(self):
        metrics = {arm: metric(0.6) for arm in candidate.ARMS}
        metrics["d"] = metric(0.621292)
        chosen = candidate._val_selection(metrics)
        self.assertEqual(chosen["selected"], "d")
        self.assertTrue(chosen["selection_posthoc"])
        self.assertFalse(chosen["primary_endpoint"])
        self.assertEqual(chosen["selection_checkpoint_step"], 500)

    def test_final_endpoint_distinct_from_val500_selection(self):
        metrics = {arm: metric(0.6) for arm in candidate.ARMS}
        final = candidate._val_selection(metrics, step=5000)
        self.assertEqual(final["selected"], "grid_probq")
        self.assertFalse(final["selection_posthoc"])
        self.assertTrue(final["primary_endpoint"])

    def test_replay_margin_and_damaged_check(self):
        saved = {arm: metric(0.6, damaged=0.44) for arm in candidate.ARMS}
        replay = {arm: metric(0.6, damaged=0.44) for arm in candidate.ARMS}
        replay["d"] = metric(0.6001, damaged=0.4401)
        self.assertTrue(candidate._comparison_to_saved(saved, replay)["passed"])
        replay["d"] = metric(0.6003, damaged=0.44)
        with self.assertRaisesRegex(ValueError, "differs from saved Val500"):
            candidate._comparison_to_saved(saved, replay)
        replay["d"] = metric(0.6, damaged=0.4403)
        with self.assertRaisesRegex(ValueError, "differs from saved Val500"):
            candidate._comparison_to_saved(saved, replay)

    def test_replay_fails_on_absent_class_or_nonfinite(self):
        saved = {arm: metric(0.6) for arm in candidate.ARMS}
        replay = {arm: metric(0.6) for arm in candidate.ARMS}
        replay["d"]["iou"][2] = None
        with self.assertRaisesRegex(ValueError, "absent-class status"):
            candidate._comparison_to_saved(saved, replay)
        replay["d"]["iou"][2] = float("nan")
        with self.assertRaisesRegex(ValueError, "nonfinite"):
            candidate._comparison_to_saved(saved, replay)

    def test_val500_selection_rejects_nonfinite_or_missing(self):
        values = {arm: metric(0.6) for arm in candidate.ARMS}
        values["d"]["foreground_miou"] = float("nan")
        with self.assertRaisesRegex(ValueError, "Invalid final Val450"):
            candidate._val_selection(values)
        del values["d"]
        with self.assertRaisesRegex(ValueError, "lacks a fixed prediction path"):
            candidate._val_selection(values)

    def test_replay_gate_precedes_test_evaluation(self):
        order = []
        formal = types.SimpleNamespace(root=Path("/tmp/source"),
                                       hashes={"checkpoint": "abc"},
                                       selected={"selected": "d"})
        def seen(name, result=None):
            order.append(name)
            return formal if result is None else result
        with mock.patch.object(candidate, "verify_release", return_value="release"), \
             mock.patch.object(candidate, "_load_tool", return_value=object()), \
             mock.patch.object(candidate, "validate_formal", side_effect=lambda *_: seen("formal")), \
             mock.patch.object(candidate, "validate_intermediate", side_effect=lambda *_: seen("500")), \
             mock.patch.object(candidate, "_protect_output", side_effect=lambda *_: seen("protect")), \
             mock.patch.object(candidate, "replay_val500", side_effect=lambda *_: seen("replay")), \
             mock.patch.object(candidate, "evaluate", side_effect=lambda *_: seen("test", {"selected_on_val": {"selected": "d"}})):
            candidate.main(["run", "--train-root", "/tmp/source", "--output", "/tmp/new-test"])
        self.assertEqual(order, ["formal", "500", "protect", "replay", "test"])

    def test_failed_replay_never_calls_test(self):
        formal = types.SimpleNamespace(root=Path("/tmp/source"),
                                       hashes={"checkpoint": "abc"},
                                       selected={"selected": "d"})
        with mock.patch.object(candidate, "verify_release", return_value="release"), \
             mock.patch.object(candidate, "_load_tool", return_value=object()), \
             mock.patch.object(candidate, "validate_formal", return_value=formal), \
             mock.patch.object(candidate, "validate_intermediate", return_value=formal), \
             mock.patch.object(candidate, "_protect_output"), \
             mock.patch.object(candidate, "replay_val500", side_effect=ValueError("replay failed")), \
             mock.patch.object(candidate, "evaluate") as evaluate:
            with self.assertRaisesRegex(ValueError, "replay failed"):
                candidate.main(["run", "--train-root", "/tmp/source", "--output", "/tmp/new-test"])
            evaluate.assert_not_called()

    def test_replay_reconstructs_all_released_evaluate_arguments(self):
        config = {name: "example" for name in
                  ("repo", "membership_root", "bank_root", "protocol", "device",
                   "workers", "seed", "key_name", "topk", "chunk_size", "lr",
                   "weight_decay", "values")}
        config.update(workers=4, seed=3407, topk=64, chunk_size=32,
                      lr=0.0001, weight_decay=0.005)
        formal = types.SimpleNamespace(saved={"config": config},
                                       checkpoint=Path("/tmp/checkpoint_000500.pt"))
        captured = []
        def stop(command):
            captured.extend(command)
            raise RuntimeError("stop after argument construction")
        tool = types.SimpleNamespace(run=types.SimpleNamespace(main=stop))
        with mock.patch.object(candidate, "_protect_output", return_value=Path("/tmp/replay")):
            with self.assertRaisesRegex(RuntimeError, "argument construction"):
                candidate.replay_val500(formal, tool, "/tmp/replay")
        self.assertEqual(captured[0], "evaluate")
        for key in config:
            self.assertIn("--" + key.replace("_", "-"), captured)
        self.assertEqual(captured[captured.index("--checkpoint") + 1],
                         "/tmp/checkpoint_000500.pt")
        self.assertEqual(captured[captured.index("--output") + 1], "/tmp/replay")


if __name__ == "__main__":
    unittest.main()
