"""Exploratory Test878 evaluation of the post-hoc 500-step A/B/C/D checkpoint.

The released training code and its formal 5000-step result remain untouched.
Before opening Test, this runner verifies the full run and 500-step checkpoint,
then replays that checkpoint on Val450 using the released evaluation entry.
The 500-step result is exploratory, never a substitute for the primary endpoint.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import re
import sys
import time
import traceback
from types import SimpleNamespace

import numpy as np
import torch

FORMAT = "SRAC_SOFT_MEMORY_Q_REBASED_EXPLORATORY_TEST500_V1"
STEP = 500
REPLAY_TOLERANCE = 0.0002  # IoU fraction = 0.02 percentage points.
ARMS = ("grid_probq", "a", "b", "c", "d")
JOINT_ARMS = ARMS[1:]
STAGES = ("preflight", "parent_smoke", "build_smoke", "smoke", "parent_full", "build", "train")
SAFE_NAME = re.compile(r"[A-Za-z0-9_-]+\Z")


def read_json(path):
    path = Path(path)
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("Expected a JSON object: " + str(path))
    return value


def require(condition, message):
    if not condition:
        raise ValueError(message)


def all_true(value):
    return isinstance(value, dict) and bool(value) and all(item is True for item in value.values())


def verify_release():
    root = Path(__file__).resolve().parent
    manifest = read_json(root / "SHA256SUMS.json")
    require(bool(manifest), "Empty Test package hash manifest")
    for name, sha in manifest.items():
        relative = Path(name)
        require(not relative.is_absolute() and ".." not in relative.parts
                and relative.as_posix() == name
                and re.fullmatch(r"[0-9a-f]{64}", sha) is not None,
                "Unsafe Test package manifest entry")
        path = root / relative
        require(path.is_file() and not path.is_symlink()
                and path.resolve().is_relative_to(root)
                and hashlib.sha256(path.read_bytes()).hexdigest() == sha,
                "Test package file changed: " + name)
    require({p.name for p in root.glob("*.py")} <= set(manifest),
            "Unbound Test package Python file")
    return hashlib.sha256((root / "SHA256SUMS.json").read_bytes()).hexdigest()


def _verify_tool_before_import(root, train_root):
    """Hash the released training files before executing any of their code."""
    manifest_path = root / "SHA256SUMS.json"
    hashes = read_json(manifest_path)
    require(bool(hashes), "Empty fix2 release hash manifest")
    for name, expected in hashes.items():
        relative = Path(name)
        require(not relative.is_absolute() and ".." not in relative.parts
                and relative.as_posix() == name
                and re.fullmatch(r"[0-9a-f]{64}", expected) is not None,
                "Unsafe fix2 release manifest entry")
        path = root / relative
        require(path.is_file() and not path.is_symlink()
                and path.resolve().is_relative_to(root)
                and hashlib.sha256(path.read_bytes()).hexdigest() == expected,
                "Fix2 release file changed before import: " + name)
    require({p.name for p in root.glob("*.py")} <= set(hashes),
            "Unbound fix2 Python file before import")
    h = hashlib.sha256()
    for path in sorted(root.glob("*.py")):
        if not path.name.startswith("test_"):
            h.update(path.name.encode())
            h.update(path.read_bytes())
    observed = h.hexdigest()
    if train_root is not None:
        state = read_json(Path(train_root) / "workflow_state.json")
        require(state.get("code_sha256") == observed,
                "Current fix2 code differs from the saved training workflow before import")
    return observed


def state_hash(state):
    """Match the released training package's module_hash without a live model."""
    h = hashlib.sha256()
    for name, value in state.items():
        require(isinstance(name, str) and torch.is_tensor(value), "Invalid head state tensor")
        tensor = value.detach().cpu().contiguous()
        h.update(name.encode())
        h.update(str(tensor.dtype).encode())
        h.update(str(tuple(tensor.shape)).encode())
        h.update(tensor.reshape(-1).view(torch.uint8).numpy().tobytes())
    return h.hexdigest()


def _load_tool(path, train_root=None):
    """Load only the exact provided fix2 package, never a shadowed module."""
    root = Path(path).expanduser().resolve(strict=True)
    require(root.is_dir() and root.name == "soft_memory_q_rebased_v1_fix2",
            "Expected the released fix2 training package directory")
    observed = _verify_tool_before_import(root, train_root)
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(root))
    names = ("run", "common", "train", "server_runtime", "model")
    modules = {name: importlib.import_module(name) for name in names}
    for name, module in modules.items():
        require(Path(module.__file__).resolve().parent == root,
                "Training module import escaped supplied fix2 directory: " + name)
    release = modules["run"].verify_release()
    require(release.get("code_sha256") == observed,
            "Imported fix2 code differs from pre-import raw code hash")
    return SimpleNamespace(root=root, release=release, **modules)


def _read_journal(path, count):
    rows = [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines()
            if line.strip()]
    require(len(rows) == count and all(isinstance(row, dict) for row in rows),
            "Saved Val450 journal is incomplete")
    return rows


def _verify_val_predictions(tool, folder, result, names):
    rows = _read_journal(folder / "images.jsonl", 450)
    confusion = {arm: np.asarray(result["metrics"][arm]["confusion"], dtype=np.int64)
                 for arm in ARMS}
    transitions = {arm: np.asarray(result["transitions"][arm]["counts"], dtype=np.int64)
                   for arm in JOINT_ARMS}
    tool.train._reopen_predictions(folder, rows, confusion, transitions, names)
    require(result.get("saved_predictions_reopened") is True
            and result.get("prediction_evidence_complete") is True,
            "Final Val450 was not saved and independently reopened")


def _val_selection(metrics, *, step=STEP):
    require(isinstance(metrics, dict) and set(ARMS) <= set(metrics),
            "Final Val450 lacks a fixed prediction path")
    values = {}
    for arm in ARMS:
        item = metrics[arm]
        require(isinstance(item, dict) and type(item.get("foreground_miou")) in (int, float)
                and np.isfinite(item["foreground_miou"])
                and 0 <= item["foreground_miou"] <= 1,
                "Invalid final Val450 foreground mIoU: " + arm)
        values[arm] = float(item["foreground_miou"])
    # This rule is evaluated on saved Val500 before any Test list/image access.
    return dict(selected=max(ARMS, key=lambda arm: values[arm]),
                criterion=("post-hoc 500-step" if step == STEP else "formal final-step")
                          + " Val450 foreground three-class mIoU; ties: grid_probq,a,b,c,d",
                tie_order=list(ARMS), val_foreground_miou=values,
                selection_posthoc=step == STEP, selection_checkpoint_step=step,
                primary_endpoint=step == 5000)


def validate_formal(train_root, tool):
    """Gate all saved training evidence before Test list/GT is accessed."""
    root = Path(train_root).expanduser().resolve(strict=True)
    train = root / "train"
    state = read_json(root / "workflow_state.json")
    summary = read_json(train / "summary.json")
    manifest = read_json(train / "manifest.json")
    val = read_json(train / "final_val" / "result.json")
    release_hash = tool.common.source_hash()
    require(state.get("format") == tool.common.FORMAT
            and state.get("complete") is True
            and state.get("execution_complete") is True
            and state.get("training_complete") is True
            and state.get("full_validation_evidence") is True
            and state.get("current_stage") == "complete"
            and state.get("smoke") is False
            and state.get("test_accessed") is False
            and state.get("code_sha256") == release_hash
            and not state.get("error"),
            "Q-rebased full workflow has not passed formal final gates")
    stages = state.get("stages", {})
    require(all(stages.get(stage, {}).get("status") == "complete" for stage in STAGES),
            "A formal source stage is incomplete")
    require(stages["train"].get("summary_sha256") == tool.common.digest(train / "summary.json"),
            "Workflow's final train-summary hash differs")
    require(summary.get("format") == tool.common.FORMAT
            and summary.get("complete") is True
            and summary.get("execution_complete") is True
            and summary.get("training_complete") is True
            and summary.get("full_validation_evidence") is True
            and summary.get("phase") == "complete"
            and summary.get("image_count") == 450
            and summary.get("smoke") is False
            and summary.get("test_accessed") is False
            and summary.get("updates_per_arm") == {a: 5000 for a in JOINT_ARMS}
            and all_true(summary.get("integrity"))
            and summary.get("old_three_arm_baseline") == "not_comparable_new_Q_source"
            and not summary.get("error"),
            "A/B/C/D final Train/Val450 summary is incomplete or failed")
    require(manifest.get("format") == tool.common.FORMAT
            and manifest.get("source_hash") == release_hash
            and len(manifest.get("train_names", [])) == 2918
            and len(manifest.get("val_names", [])) == 450
            and len(set(manifest["train_names"])) == 2918
            and len(set(manifest["val_names"])) == 450
            and not (set(manifest["train_names"]) & set(manifest["val_names"]))
            and manifest.get("old_three_arm_baseline") == "not_comparable_new_Q_source",
            "Formal training manifest/splits/code do not match")
    require(val.get("format") == tool.common.FORMAT
            and val.get("phase") == "evaluation"
            and val.get("execution_complete") is True
            and val.get("whole_val450_processed") is True
            and val.get("image_count") == 450
            and val.get("primary_endpoint") is True
            and val.get("full_validation_evidence") is True
            and val.get("final_integrity_pending") is False
            and val.get("test_accessed") is False
            and val.get("smoke") is False
            and all_true(val.get("final_integrity"))
            and val.get("final_integrity") == summary.get("integrity")
            and val.get("metrics") == summary.get("metrics"),
            "Saved last-step Val450 endpoint is incomplete or differs from training")
    guard = summary.get("guard_report")
    require(isinstance(guard, dict) and guard.get("restored") is True
            and not guard.get("restore_conflicts")
            and val.get("guard_report") == guard,
            "Final training PoolGuard did not restore cleanly")
    checkpoint = (train / "checkpoints" / "checkpoint_last.pt").resolve(strict=True)
    checkpoint_manifest = read_json(checkpoint.with_suffix(checkpoint.suffix + ".json"))
    require(Path(summary.get("last_checkpoint", "")).resolve() == checkpoint
            and summary.get("checkpoint") == checkpoint_manifest
            and checkpoint_manifest.get("format") == tool.common.FORMAT
            and checkpoint_manifest.get("file") == checkpoint.name
            and checkpoint_manifest.get("sha256") == tool.common.digest(checkpoint)
            and checkpoint_manifest.get("step") == 5000
            and checkpoint_manifest.get("mode") == "train"
            and checkpoint_manifest.get("smoke") is False
            and checkpoint_manifest.get("training_complete") is True
            and checkpoint_manifest.get("source_hash") == release_hash
            and checkpoint_manifest.get("protocol_info") == manifest.get("protocol_info"),
            "Last-step checkpoint manifest/hash does not match final training")
    saved = torch.load(checkpoint, map_location="cpu", weights_only=False)
    require(saved.get("format") == tool.common.FORMAT
            and saved.get("step") == 5000
            and saved.get("mode") == "train"
            and saved.get("smoke") is False
            and saved.get("training_complete") is True
            and saved.get("test_accessed") is False
            and saved.get("updates_per_arm") == {a: 5000 for a in JOINT_ARMS}
            and saved.get("source_hash") == release_hash
            and saved.get("protocol_info") == manifest.get("protocol_info")
            and saved.get("old_three_arm_baseline") == "not_comparable_new_Q_source"
            and set(saved.get("heads", {})) == set(JOINT_ARMS)
            and saved.get("config") == summary.get("arguments")
            and all(state_hash(saved["heads"][a]) ==
                    checkpoint_manifest.get("head_hashes", {}).get(a) for a in JOINT_ARMS),
            "Serialized final checkpoint has wrong steps, model or source binding")
    fingerprints = train / "input_fingerprints.json"
    require(summary.get("input_fingerprints_sha256") == tool.common.digest(fingerprints),
            "Final source-file ledger changed")
    ledger = read_json(fingerprints)
    require(bool(ledger) and saved.get("input_file_sha256") and
            all(ledger.get(path) == sha for path, sha in saved["input_file_sha256"].items()),
            "Saved checkpoint input ledger conflicts with final source ledger")
    for index, (raw_path, sha) in enumerate(ledger.items(), 1):
        path = Path(raw_path)
        require(path.is_file() and tool.common.digest(path) == sha,
                "Training source image/artifact changed: " + raw_path)
        if index % 500 == 0:
            print("Train/Val source file hashes verified %d/%d" % (index, len(ledger)), flush=True)
    _verify_val_predictions(tool, train / "final_val", val, manifest["val_names"])
    selection = _val_selection(val["metrics"], step=5000)
    return SimpleNamespace(root=root, train=train, state=state, summary=summary,
        manifest=manifest, val=val, checkpoint=checkpoint, checkpoint_manifest=checkpoint_manifest,
        saved=saved, selected=selection,
        hashes={"workflow_state": tool.common.digest(root / "workflow_state.json"),
                "train_manifest": tool.common.digest(train / "manifest.json"),
                "train_summary": tool.common.digest(train / "summary.json"),
                "val_result": tool.common.digest(train / "final_val" / "result.json"),
                "checkpoint": tool.common.digest(checkpoint),
                "checkpoint_manifest": tool.common.digest(checkpoint.with_suffix(checkpoint.suffix + ".json")),
                "input_fingerprints": tool.common.digest(fingerprints)})


def validate_intermediate(formal, tool):
    """Bind saved Val500 to the actual serialized checkpoint; no Test access."""
    train = formal.train
    path = (train / "checkpoints" / "checkpoint_000500.pt").resolve(strict=True)
    manifest_path = path.with_suffix(path.suffix + ".json")
    record = read_json(manifest_path)
    val_path = train / "val_step_000500" / "result.json"
    val = read_json(val_path)
    require(path.parent == formal.checkpoint.parent
            and record.get("format") == tool.common.FORMAT
            and record.get("file") == path.name
            and record.get("sha256") == tool.common.digest(path)
            and record.get("step") == STEP
            and record.get("mode") == "train"
            and record.get("smoke") is False
            and record.get("training_complete") is False
            and record.get("source_hash") == formal.saved["source_hash"]
            and record.get("protocol_info") == formal.saved["protocol_info"]
            and record.get("old_three_arm_baseline") == "not_comparable_new_Q_source",
            "Saved 500-step checkpoint manifest/source does not match completed run")
    saved = torch.load(path, map_location="cpu", weights_only=False)
    require(saved.get("format") == tool.common.FORMAT
            and saved.get("step") == STEP
            and saved.get("mode") == "train"
            and saved.get("smoke") is False
            and saved.get("training_complete") is False
            and saved.get("test_accessed") is False
            and saved.get("updates_per_arm") == {a: STEP for a in JOINT_ARMS}
            and saved.get("source_hash") == record["source_hash"]
            and saved.get("protocol_info") == record["protocol_info"]
            and saved.get("config") == formal.saved["config"]
            and saved.get("initial_head_hashes") == formal.saved.get("initial_head_hashes")
            and saved.get("old_three_arm_baseline") == "not_comparable_new_Q_source"
            and set(saved.get("heads", {})) == set(JOINT_ARMS)
            and all(state_hash(saved["heads"][arm]) == record.get("head_hashes", {}).get(arm)
                    for arm in JOINT_ARMS),
            "Serialized 500-step checkpoint differs from its manifest or final-run lineage")
    final_ledger = read_json(train / "input_fingerprints.json")
    require(isinstance(saved.get("input_file_sha256"), dict)
            and bool(saved["input_file_sha256"])
            and all(final_ledger.get(p) == sha for p, sha in saved["input_file_sha256"].items()),
            "500-step input ledger conflicts with completed run")
    require(val.get("format") == tool.common.FORMAT
            and val.get("phase") == "evaluation"
            and val.get("execution_complete") is True
            and val.get("whole_val450_processed") is True
            and val.get("image_count") == 450
            and val.get("full_validation_evidence") is False
            and val.get("final_integrity_pending") is True
            and val.get("prediction_evidence_complete") is False
            and val.get("smoke") is False
            and val.get("test_accessed") is False,
            "Original 500-step Val450 intermediate report is incomplete")
    selection = _val_selection(val.get("metrics"))
    require(selection["selected"] == "d",
            "Expected predeclared D to lead saved Val500; stop before Test")
    formal.final_hashes = dict(formal.hashes)
    formal.checkpoint = path
    formal.checkpoint_manifest = record
    formal.saved = saved
    formal.val = val
    formal.val_path = val_path
    formal.selected = selection
    formal.hashes.update(val_result=tool.common.digest(val_path),
                         checkpoint=tool.common.digest(path),
                         checkpoint_manifest=tool.common.digest(manifest_path),
                         formal_final_val_result=formal.final_hashes["val_result"],
                         formal_final_checkpoint=formal.final_hashes["checkpoint"])
    return formal


def _comparison_to_saved(saved_metrics, replay_metrics):
    maximum = 0.0
    differences = {}
    for arm in ARMS:
        expected = saved_metrics[arm]
        observed = replay_metrics[arm]
        require(len(expected["iou"]) == len(observed["iou"]) == 4,
                "500-step Val replay has wrong class count: " + arm)
        fields = {"foreground_miou": (expected["foreground_miou"], observed["foreground_miou"])}
        for index, (left, right) in enumerate(zip(expected["iou"], observed["iou"])):
            require((left is None) == (right is None),
                    "500-step Val replay changed absent-class status: " + arm)
            if left is not None:
                fields["iou_%d" % index] = (left, right)
        arm_differences = {name: abs(float(left) - float(right))
                           for name, (left, right) in fields.items()}
        require(all(np.isfinite(value) for value in arm_differences.values()),
                "500-step Val replay contains nonfinite IoU: " + arm)
        differences[arm] = arm_differences
        maximum = max(maximum, *arm_differences.values())
    require(maximum <= REPLAY_TOLERANCE,
            "Checkpoint Val450 replay differs from saved Val500 by more than %.4f pp: %.4f pp" %
            (100 * REPLAY_TOLERANCE, 100 * maximum))
    return dict(passed=True, tolerance_pp=100 * REPLAY_TOLERANCE,
                max_difference_pp=100 * maximum,
                per_metric_abs_difference_pp={arm: {name: 100*x for name, x in values.items()}
                                              for arm, values in differences.items()})


def replay_val500(formal, tool, output):
    """Re-run released checkpoint Val450 and reopen predictions before Test."""
    output = _protect_output(output, formal, tool)
    config = formal.saved["config"]
    command = ["evaluate"]
    for name in ("repo", "membership_root", "bank_root", "protocol", "device", "workers",
                 "seed", "key_name", "topk", "chunk_size", "lr", "weight_decay", "values"):
        require(name in config and config[name] is not None,
                "500-step checkpoint lacks evaluation argument: " + name)
        command.extend(("--" + name.replace("_", "-"), str(config[name])))
    command.extend(("--checkpoint", str(formal.checkpoint), "--output", str(output)))
    tool.run.main(command)
    summary = read_json(output / "summary.json")
    result = read_json(output / "val" / "result.json")
    require(summary.get("complete") is True
            and summary.get("execution_complete") is True
            and summary.get("full_validation_evidence") is False
            and summary.get("primary_endpoint") is False
            and summary.get("checkpoint_step") == STEP
            and summary.get("image_count") == 450
            and all_true(summary.get("integrity"))
            and result.get("execution_complete") is True
            and result.get("whole_val450_processed") is True
            and result.get("image_count") == 450
            and result.get("saved_predictions_reopened") is True
            and result.get("prediction_evidence_complete") is True
            and result.get("primary_endpoint") is False
            and result.get("full_validation_evidence") is False
            and result.get("final_integrity_pending") is False
            and all_true(result.get("final_integrity"))
            and summary.get("guard_report", {}).get("restored") is True,
            "Serialized checkpoint Val450 replay failed verification")
    rows = _read_journal(output / "val" / "images.jsonl", 450)
    tool.train._reopen_predictions(output / "val", rows,
        {arm: np.asarray(result["metrics"][arm]["confusion"], dtype=np.int64) for arm in ARMS},
        {arm: np.asarray(result["transitions"][arm]["counts"], dtype=np.int64)
         for arm in JOINT_ARMS}, formal.manifest["val_names"])
    comparison = _comparison_to_saved(formal.val["metrics"], result["metrics"])
    comparison.update(format=FORMAT, checkpoint_step=STEP,
                      original_val500_sha256=formal.hashes["val_result"],
                      replay_result_sha256=tool.common.digest(output / "val" / "result.json"),
                      replay_checkpoint_sha256=formal.hashes["checkpoint"],
                      replay_output=str(output))
    tool.common.write_json(output / "test500_replay_gate.json", comparison)
    formal.replay = comparison
    formal.replay_output = output
    formal.replay_result_hash = comparison["replay_result_sha256"]
    formal.replay_hash = tool.common.digest(output / "test500_replay_gate.json")
    return formal


def _canonical_test_split(source, formal):
    protocol = read_json(source)
    require(protocol.get("format") == "SOFT_MEMORY_Q_SOURCE_V1", "Wrong Q source protocol")
    e0 = read_json(protocol["e0_metadata_protocol"])
    split_paths = e0["input_paths"]
    train_list, val_list = (Path(split_paths[name]).resolve(strict=True)
                            for name in ("train_list", "val_list"))
    require(train_list.name == "train_set.txt" and val_list.name == "val_set.txt"
            and train_list.parent == val_list.parent
            and train_list.parent.name == "standard_ML",
            "Require canonical standard_ML split directory")
    for path, expected in ((train_list, formal.manifest["train_names"]),
                           (val_list, formal.manifest["val_names"])):
        names = [row.strip() for row in path.read_text(encoding="utf-8").splitlines() if row.strip()]
        require(names == expected, "Current Train/Val list differs from final training: " + str(path))
    test_list = train_list.parent / "test_set.txt"
    names = [row.strip() for row in test_list.read_text(encoding="utf-8").splitlines() if row.strip()]
    require(len(names) == 878 and len(set(names)) == 878
            and all(SAFE_NAME.fullmatch(name) for name in names)
            and not (set(names) & (set(formal.manifest["train_names"]) |
                                   set(formal.manifest["val_names"]))),
            "Canonical Test878 is incomplete, unsafe, repeated or overlaps Train/Val")
    dataset = Path(e0["arguments"]["dataset"]).resolve(strict=True)
    for index, name in enumerate(names, 1):
        for subdir, suffix in (("pre-event", "_pre_disaster.tif"),
                               ("post-event", "_post_disaster.tif"),
                               ("target", "_building_damage.tif")):
            path = dataset / subdir / (name + suffix)
            require(path.is_file(), "Scored Test needs RGB, SAR and ground truth: " + str(path))
        if index % 200 == 0:
            print("Test file existence checked %d/878" % index, flush=True)
    return test_list, names, dataset


def _protect_output(output, formal, tool):
    """Never write Test artifacts into source, training or the released tool."""
    source = read_json(formal.saved["config"]["protocol"])
    e0 = read_json(source["e0_metadata_protocol"])
    dataset = Path(e0["arguments"]["dataset"]).expanduser().resolve(strict=True)
    protected = (formal.root, formal.train, tool.root,
                 Path(__file__).resolve().parent, dataset)
    path = Path(output).expanduser().resolve()
    require(not path.exists(), "Use a fresh Test output directory; preserving: " + str(path))
    require(all(not path.is_relative_to(root) for root in protected),
            "Test output must be outside the training run, released tool and dataset")
    return path


def metrics(cm, inherited):
    base = inherited._metrics(cm)
    iou = base["iou"]
    base["four_class_miou"] = sum(x if x is not None else 0.0 for x in iou) / 4
    base["four_class_average"] = "fixed classes 0/1/2/3; absent IoU contributes zero"
    return base


def _reopen(folder, rows, expected, event_expected, names, tool):
    rebuilt = {arm: np.zeros((4, 4), dtype=np.int64) for arm in ARMS}
    events = {}
    require(len(rows) == len(names), "Incomplete Test878 prediction journal")
    for index, row in enumerate(rows):
        require(row.get("index") == index and row.get("image") == names[index]
                and row.get("file") == "predictions/%04d.npz" % index,
                "Saved Test prediction order/path differs from the locked list")
        path = folder / row["file"]
        require(path.is_file() and tool.common.digest(path) == row.get("sha256"),
                "Saved Test prediction file changed: " + str(path))
        with np.load(path, allow_pickle=False) as archive:
            require(set(archive.files) == {"target"} | {"prediction_" + a for a in ARMS},
                    "Saved Test prediction schema differs")
            target = archive["target"]
            require(target.dtype == np.uint8, "Saved Test target dtype differs")
            event = events.setdefault(row["event"],
                {a: np.zeros((4, 4), dtype=np.int64) for a in ARMS})
            for arm in ARMS:
                prediction = archive["prediction_" + arm]
                require(prediction.dtype == np.uint8, "Saved Test prediction dtype differs")
                cm = tool.train._confusion(target, prediction)
                require(cm.tolist() == row["confusion"][arm],
                        "Saved Test per-image confusion differs: " + arm)
                rebuilt[arm] += cm
                event[arm] += cm
    for arm in ARMS:
        require(np.array_equal(rebuilt[arm], expected[arm]),
                "Reopened Test878 confusion differs: " + arm)
    for event, arms in event_expected.items():
        require(event in events and all(np.array_equal(events[event][a], arms[a]) for a in ARMS),
                "Reopened Test878 event confusion differs: " + event)
    require(set(events) == set(event_expected), "Test event list changed on reopen")
    return rebuilt, events


def evaluate(formal, tool, output):
    output = _protect_output(output, formal, tool)
    output.mkdir(parents=True)
    write = tool.common.write_json
    summary = dict(format=FORMAT, complete=False, full_test_evidence=False,
                   primary_endpoint=False, exploratory=True,
                   posthoc_checkpoint_selection=True, checkpoint_step=STEP,
                   formal_training_endpoint_step=5000, training=False,
                   test_accessed=False, selected_on_val=formal.selected,
                   source_run=str(formal.root), source_hashes=formal.hashes,
                   formal_5000_source_verified=True,
                   val500_replay_gate=formal.replay,
                   val500_replay_gate_sha256=formal.replay_hash,
                   training_package_release=tool.release,
                   test_package_manifest_sha256=verify_release())
    write(output / "summary.json", summary)
    started = time.monotonic()
    try:
        # This Val-frozen selection is written before the first Test list read.
        write(output / "val_locked_selection.json", formal.selected)
        summary["val_locked_selection_sha256"] = tool.common.digest(output / "val_locked_selection.json")
        summary["test_accessed"] = True
        write(output / "summary.json", summary)
        source = formal.saved["config"]["protocol"]
        test_list, names, dataset = _canonical_test_split(source, formal)
        summary.update(test_list=str(test_list), test_list_sha256=tool.common.digest(test_list),
                       test_image_count_expected=878, dataset=str(dataset), phase="inference")
        write(output / "summary.json", summary)
        args = SimpleNamespace(**formal.saved["config"])
        args.smoke = False
        args.mode = "train"  # strict full-bank gate; no optimizer is constructed.
        args.output = str(output)
        require(args.topk == 64 and args.key_name in ("t128", "f256")
                and args.values == str(formal.root / "values")
                and args.bank_root == str(formal.root / "parent")
                and args.protocol == formal.state["arguments"]["protocol"],
                "Final checkpoint does not bind this complete parent/child bank")
        parent_runtime = tool.server_runtime.Runtime
        class TestRuntime(parent_runtime):
            def __enter__(self):
                super().__enter__()
                try:
                    require(self.protocol_info == formal.saved["protocol_info"],
                            "Test source/bank/runtime differs from saved final checkpoint")
                    for name in names:
                        established = {key: Path(path).resolve() for key, path in
                            self.deps.sample_paths(self.bundle["args"].dataset, name).items()}
                        expected = {"pre": dataset / "pre-event" / (name + "_pre_disaster.tif"),
                                    "post": dataset / "post-event" / (name + "_post_disaster.tif"),
                                    "label": dataset / "target" / (name + "_building_damage.tif")}
                        require(established == expected,
                                "Test path differs from established BRIGHT labelled loader: " + name)
                    # Reuse the frozen forward/Reader verbatim. Its Val-only
                    # loader gate is retargeted only in this Test subclass,
                    # after the canonical disjoint Test878 list was checked.
                    self._val_set = set(names)
                    return self
                except BaseException:
                    self.close(*sys.exc_info())
                    raise
        runtime = TestRuntime(args, output)
        confusion = {a: np.zeros((4, 4), dtype=np.int64) for a in ARMS}
        event_confusion = {}
        rows = []
        heads = {}
        output_predictions = output / "predictions"
        output_predictions.mkdir()
        with runtime, torch.no_grad(), (output / "images.jsonl").open("x", encoding="utf-8") as journal:
            require(runtime.device.type == "cuda", "Exploratory Test requires the original CUDA numerical protocol")
            for arm in JOINT_ARMS:
                head = tool.model.JointRegionMemoryClassifier(chunk_size=args.chunk_size).to(runtime.device)
                head.load_state_dict(formal.saved["heads"][arm], strict=True)
                head.requires_grad_(False).eval()
                require(tool.common.module_hash(head) == formal.checkpoint_manifest["head_hashes"][arm],
                        "Loaded Test head differs from saved final checkpoint: " + arm)
                heads[arm] = head
            for index, batch in enumerate(runtime.batches(names, train=False, seed=args.seed)):
                example = runtime.prepare(batch)
                tool.train._assert_example(example)
                require(index < 878 and example.image == names[index],
                        "Test loader order differs from fixed Test878 split")
                target = example.target.detach().cpu().numpy().astype(np.uint8)
                base = example.common["base_probability_full"]
                require(bool(torch.isfinite(base).all()), "Nonfinite grid_probq on Test")
                predictions = {"grid_probq": base.argmax(1).cpu().numpy().astype(np.uint8)}
                for arm in JOINT_ARMS:
                    probability = heads[arm](**example.common, **example.supports[arm])["probabilities"]
                    require(bool(torch.isfinite(probability).all()), "Nonfinite Test head: " + arm)
                    predictions[arm] = probability.argmax(1).cpu().numpy().astype(np.uint8)
                per_image = {arm: tool.train._confusion(target, predictions[arm]) for arm in ARMS}
                event = event_confusion.setdefault(example.event,
                    {arm: np.zeros((4, 4), dtype=np.int64) for arm in ARMS})
                for arm in ARMS:
                    confusion[arm] += per_image[arm]
                    event[arm] += per_image[arm]
                relative = "predictions/%04d.npz" % index
                np.savez_compressed(output / relative, target=target,
                                    **{"prediction_" + arm: predictions[arm] for arm in ARMS})
                row = dict(index=index, image=example.image, event=example.event,
                           file=relative, sha256=tool.common.digest(output / relative),
                           confusion={arm: per_image[arm].tolist() for arm in ARMS},
                           diagnostics=example.diagnostics)
                journal.write(json.dumps(row, ensure_ascii=False, allow_nan=False, default=str) + "\n")
                journal.flush()
                rows.append(row)
                if (index + 1) % 10 == 0 or index == 877:
                    print("Exploratory Test500 %d/878; final integrity pending" % (index + 1), flush=True)
            require(len(rows) == 878, "Test loader did not cover all 878 images")
            reopened, events = _reopen(output, rows, confusion, event_confusion, names, tool)
            integrity = tool.train._checked_verify(runtime)
            require(tool.common.source_hash() == formal.saved["source_hash"],
                    "Training code changed during Test")
            require(all(tool.common.module_hash(heads[a]) ==
                        formal.checkpoint_manifest["head_hashes"][a] for a in JOINT_ARMS),
                    "A Test head changed despite inference-only execution")
        guard = runtime.guard_report
        require(isinstance(guard, dict) and guard.get("restored") is True
                and not guard.get("restore_conflicts"), "Test PoolGuard did not restore cleanly")
        require(tool.common.digest(test_list) == summary["test_list_sha256"],
                "Test list changed during inference")
        require(verify_release() == summary["test_package_manifest_sha256"],
                "Test package changed during long inference")
        require(_verify_tool_before_import(tool.root, formal.root) == formal.saved["source_hash"],
                "Fix2 training code changed during long inference")
        input_fingerprints = {str(path): sha for path, sha in runtime.input_ledger.items()}
        write(output / "input_fingerprints.json", input_fingerprints)
        input_fingerprints_sha256 = tool.common.digest(output / "input_fingerprints.json")
        for label, path in (("workflow_state", formal.root / "workflow_state.json"),
                            ("train_manifest", formal.train / "manifest.json"),
                            ("train_summary", formal.train / "summary.json"),
                            ("val_result", formal.val_path),
                            ("checkpoint", formal.checkpoint),
                            ("checkpoint_manifest", formal.checkpoint.with_suffix(formal.checkpoint.suffix + ".json")),
                            ("input_fingerprints", formal.train / "input_fingerprints.json"),
                            ("formal_final_val_result", formal.train / "final_val" / "result.json"),
                            ("formal_final_checkpoint", formal.train / "checkpoints" / "checkpoint_last.pt")):
            require(tool.common.digest(path) == formal.hashes[label],
                    "Train/Val500/final evidence changed during Test: " + label)
        require(tool.common.digest(formal.replay_output / "test500_replay_gate.json") == formal.replay_hash
                and tool.common.digest(formal.replay_output / "val" / "result.json") == formal.replay_result_hash,
                "Checkpoint Val500 replay evidence changed during Test")
        result = dict(format=FORMAT, split="standard_ML/test_set.txt", image_count=878,
                      execution_complete=True, full_test_evidence=True, training=False,
                      primary_endpoint=False, exploratory=True,
                      posthoc_checkpoint_selection=True, checkpoint_step=STEP,
                      formal_training_endpoint_step=5000,
                      test_accessed=True, no_test_based_selection=True,
                      selected_on_val=formal.selected,
                      formal_5000_source_verified=True,
                      val500_replay_gate=formal.replay,
                      val500_replay_gate_sha256=formal.replay_hash,
                      test_list_sha256=summary["test_list_sha256"],
                      input_fingerprints_sha256=input_fingerprints_sha256,
                      source_hashes=formal.hashes,
                      test_package_manifest_sha256=summary["test_package_manifest_sha256"],
                      metrics={arm: metrics(reopened[arm], tool.train) for arm in ARMS},
                      per_event={event: {arm: metrics(cm, tool.train) for arm, cm in arms.items()}
                                 for event, arms in events.items()},
                      saved_predictions_reopened=True, runtime_integrity=integrity,
                      pool_guard=guard, elapsed_seconds=time.monotonic()-started)
        write(output / "result.json", result)
        summary.update(phase="complete", complete=True, full_test_evidence=True,
                       image_count=878, result_sha256=tool.common.digest(output / "result.json"),
                       input_fingerprints_sha256=input_fingerprints_sha256,
                       runtime_integrity=integrity, pool_guard=guard,
                       elapsed_seconds=time.monotonic()-started)
        write(output / "summary.json", summary)
        return result
    except BaseException as exc:
        summary.update(complete=False, full_test_evidence=False,
                       error=type(exc).__name__ + ": " + str(exc))
        write(output / "summary.json", summary)
        (output / "traceback.txt").write_text(traceback.format_exc(), encoding="utf-8")
        raise


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("command", choices=("plan", "run", "report"))
    p.add_argument("--train-root", required=False)
    p.add_argument("--tool", default="/root/shared-nvme/BRIGHT-master/New/soft_memory_q_rebased_v1_fix2")
    p.add_argument("--output")
    p.add_argument("--replay-output", help="Fresh sibling directory for checkpoint Val450 replay")
    return p


def main(argv=None):
    args = parser().parse_args(argv)
    own_release = verify_release()
    if args.command == "report":
        require(args.output, "--output is required for report")
        folder = Path(args.output)
        summary = read_json(folder / "summary.json")
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        if summary.get("complete") is True:
            result = read_json(folder / "result.json")
            print("Exploratory 500-step Test878; 5000-step Val450 remains the formal endpoint.")
            for arm in ARMS:
                score = result["metrics"][arm]
                print("%s: foreground3=%.4f%% fourclass=%.4f%% IoU=%s" %
                      (arm, 100*score["foreground_miou"], 100*score["four_class_miou"],
                       " / ".join("%.4f" % (100*x) if x is not None else "NA"
                                  for x in score["iou"])))
            print("Post-hoc Val500-selected path:", result["selected_on_val"]["selected"])
        return
    require(args.train_root, "--train-root is required")
    tool = _load_tool(args.tool, args.train_root)
    formal = validate_intermediate(validate_formal(args.train_root, tool), tool)
    if args.command == "plan":
        print(json.dumps(dict(format=FORMAT, stage="ready_no_Test_access",
                              formal_5000_train_val450_verified=True,
                              val500_checkpoint_verified=True,
                              val500_replay_pending=True,
                              exploratory=True, primary_endpoint=False,
                              posthoc_checkpoint_selection=True,
                              checkpoint_step=STEP, train_root=str(formal.root),
                              selected_on_val=formal.selected,
                              checkpoint_sha256=formal.hashes["checkpoint"],
                              test_package_manifest_sha256=own_release,
                              test_accessed=False), ensure_ascii=False, indent=2))
        return
    require(args.output, "--output is required for run")
    _protect_output(args.output, formal, tool)
    replay_output = args.replay_output or (str(args.output) + ".val500_replay")
    require(Path(replay_output).expanduser().resolve() != Path(args.output).expanduser().resolve(),
            "Val500 replay and Test output must be separate")
    replay_val500(formal, tool, replay_output)
    result = evaluate(formal, tool, args.output)
    print("EXPLORATORY TEST500/878 COMPLETE. No training. Post-hoc Val500 path:",
          result["selected_on_val"]["selected"])


if __name__ == "__main__":
    main()
