import json
import tempfile
import unittest
from pathlib import Path

from overfit_audit import FORMAT, audit, load_loss_windows, load_val, render, val_path


ARMS = ("grid_probq", "a", "b", "c", "d")


def metric(foreground, damaged=None):
    ious = [0.96, foreground + 0.04, damaged if damaged is not None else foreground,
            2 * foreground - (damaged if damaged is not None else foreground) - 0.04]
    return {"iou": ious, "foreground_miou": sum(ious[1:]) / 3,
            "target_pixels": [1000, 300, 100, 200],
            "precision": [0.90, 0.80, 0.50, 0.70],
            "recall": [0.90, 0.80, 0.40, 0.70]}


def fixture(root, step, *, complete=True):
    base = {"grid_probq": metric(0.60), "a": metric(0.61), "b": metric(0.615),
            "c": metric(0.612), "d": metric(0.63 if step == 500 else 0.59,
                                             0.64 if step == 500 else 0.54)}
    event = {arm: dict(value) for arm, value in base.items()}
    result = {"format": FORMAT, "phase": "evaluation", "image_count": 450,
              "execution_complete": True, "whole_val450_processed": True,
              "smoke": False, "test_accessed": False, "metrics": base,
              "per_event": {"event-one": event}, "full_validation_evidence": step == 5000 and complete,
              "transitions": {"d": {"rescued_by_gt_class": [0, 0, 20, 0],
                                    "harmed_by_gt_class": [0, 0, 15, 0],
                                    "correct_intact_changed_to_damaged": 11,
                                    "damaged_previously_intact_now_damaged": 17}},
              "primary_endpoint": step == 5000 and complete,
              "saved_predictions_reopened": step == 5000 and complete,
              "final_integrity_pending": not (step == 5000 and complete)}
    path = val_path(root, step)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result), encoding="utf-8")


class AuditTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        (self.root / "train").mkdir()
        (self.root / "workflow_state.json").write_text(json.dumps({
            "format": FORMAT, "complete": True, "training_complete": True,
            "full_validation_evidence": True}), encoding="utf-8")
        (self.root / "train" / "summary.json").write_text(json.dumps({
            "format": FORMAT, "complete": True, "training_complete": True,
            "full_validation_evidence": True,
            "updates_per_arm": {arm: 5000 for arm in ARMS[1:]}}), encoding="utf-8")
        for step in (500, 1500, 5000):
            fixture(self.root, step)

    def test_reads_reports_and_marks_500_formal_boundary(self):
        report = audit(self.root)
        self.assertTrue(report["formal"])
        self.assertEqual(set(report["val"]), {500, 1500, 5000})
        text = render(self.root, report)
        self.assertIn("D−grid_probq", text)
        self.assertIn("event-one", text)
        self.assertIn("原正确完好→受损", text)
        self.assertIn("20", text)
        self.assertIn("5000 步为正式 Val450 末步", text)
        self.assertIn("不能单凭此表证明", text)

    def test_5000_not_formal_without_integrity(self):
        fixture(self.root, 5000, complete=False)
        report = audit(self.root)
        self.assertFalse(report["formal"])
        self.assertNotIn(5000, report["val"])
        self.assertTrue(any("5000 步 Val450 不可用" in item for item in report["warnings"]))

    def test_missing_middle_val_is_reported(self):
        val_path(self.root, 1500).unlink()
        report = audit(self.root)
        self.assertNotIn(1500, report["val"])
        self.assertIn("1500 步 Val450 不可用", "\n".join(report["warnings"]))

    def test_rejects_metric_inconsistency(self):
        path = val_path(self.root, 500)
        report = json.loads(path.read_text())
        report["metrics"]["d"]["foreground_miou"] = 0.01
        path.write_text(json.dumps(report))
        with self.assertRaisesRegex(ValueError, "不一致"):
            load_val(self.root, 500)

    def test_loss_windows_mean_and_median_ignore_bad_rows(self):
        path = self.root / "train" / "train.jsonl"
        rows = [
            {"step": 1, "lr": 1e-4, "heads": {arm: {"loss": 2.0} for arm in ARMS[1:]}},
            {"step": 2, "lr": 2e-4, "heads": {arm: {"loss": 4.0} for arm in ARMS[1:]}},
            {"step": 1, "lr": 3e-4, "heads": {arm: {"loss": 100.0} for arm in ARMS[1:]}}
        ]
        path.write_text("\n".join(json.dumps(row) for row in rows) + "\nBAD\n")
        windows, warnings = load_loss_windows(path)
        self.assertEqual(windows[(1, 500)]["arms"]["d"]["mean"], 3.0)
        self.assertEqual(windows[(1, 500)]["arms"]["d"]["median"], 3.0)
        self.assertAlmostEqual(windows[(1, 500)]["lr_mean"], 1.5e-4)
        self.assertTrue(any("重复" in item for item in warnings))
        self.assertTrue(any("不是完整 JSON" in item for item in warnings))


if __name__ == "__main__":
    unittest.main()
