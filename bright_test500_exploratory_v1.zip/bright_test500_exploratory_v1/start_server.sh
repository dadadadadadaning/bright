#!/usr/bin/env bash
# Exploratory Test878 at the saved 500-step checkpoint. No training or resume.
set -euo pipefail
BRIGHT_TEST500_TOOL="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
BRIGHT_PY="${BRIGHT_PY:-/root/shared-nvme/conda-envs/bright4090/bin/python}"
BRIGHT_TRAIN_ROOT="${BRIGHT_TRAIN_ROOT:-/root/shared-nvme/BRIGHT-checkpoints/SRAC_SOFT_MEMORY_Q_REBASED_V1/run_20261014_202057_full_fEYBZv7D}"
BRIGHT_FIX2_TOOL="${BRIGHT_FIX2_TOOL:-/root/shared-nvme/BRIGHT-master/New/soft_memory_q_rebased_v1_fix2}"
BRIGHT_TEST500_BASE="${BRIGHT_TEST500_BASE:-/root/shared-nvme/BRIGHT-checkpoints/SRAC_SOFT_MEMORY_Q_REBASED_TEST500_EXPLORATORY_V1}"
export PYTHONDONTWRITEBYTECODE=1
export CUDA_LAUNCH_BLOCKING="${CUDA_LAUNCH_BLOCKING:-1}"

test -x "$BRIGHT_PY"
test -s "$BRIGHT_TEST500_TOOL/test500.py"
test -s "$BRIGHT_FIX2_TOOL/run.py"
for BRIGHT_REL in workflow_state.json train/summary.json train/final_val/result.json \
  train/val_step_000500/result.json train/checkpoints/checkpoint_000500.pt \
  train/checkpoints/checkpoint_000500.pt.json; do
  test -s "$BRIGHT_TRAIN_ROOT/$BRIGHT_REL" || {
    echo "缺少 500 步或正式末步来源文件：$BRIGHT_TRAIN_ROOT/$BRIGHT_REL" >&2
    exit 1
  }
done

mkdir -p "$BRIGHT_TEST500_BASE"
BRIGHT_TEST500_LOG="$(mktemp "$BRIGHT_TEST500_BASE/run_$(date +%Y%m%d_%H%M%S)_XXXXXXXX.log")"
BRIGHT_TEST500_OUTPUT="${BRIGHT_TEST500_LOG%.log}"
test ! -e "$BRIGHT_TEST500_OUTPUT"
nohup "$BRIGHT_PY" -u "$BRIGHT_TEST500_TOOL/test500.py" run \
  --train-root "$BRIGHT_TRAIN_ROOT" --tool "$BRIGHT_FIX2_TOOL" \
  --output "$BRIGHT_TEST500_OUTPUT" > "$BRIGHT_TEST500_LOG" 2>&1 < /dev/null &
BRIGHT_TEST500_PID=$!
printf '后台PID=%s\n来源训练=%s\n探索性Test目录=%s\nVal500重放目录=%s.val500_replay\n日志=%s\n' \
  "$BRIGHT_TEST500_PID" "$BRIGHT_TRAIN_ROOT" "$BRIGHT_TEST500_OUTPUT" \
  "$BRIGHT_TEST500_OUTPUT" "$BRIGHT_TEST500_LOG"
printf '查看进度：tail -n 60 -f "%s"\n' "$BRIGHT_TEST500_LOG"
printf '读取报告："%s" "%s/test500.py" report --output "%s"\n' \
  "$BRIGHT_PY" "$BRIGHT_TEST500_TOOL" "$BRIGHT_TEST500_OUTPUT"
printf 'PID 只表示后台进程创建；先重放 Val450，通过后才读取 Test878。500 步为探索性结果。\n'
