# 500 步检查点的探索性 Test878

这套独立工具使用已完成 A/B/C/D 运行的 `checkpoint_000500.pt`，不改动原训练包、运行记录或 5000 步正式成绩。**本次选择 500 步是在看过 Val 曲线之后，因此所有 Test500 数字都标记为探索性，不可替代预定的 5000 步正式终点。** 预先指定 D 为本次候选；同一次前向产生 `grid_probq`、A、B、C、D 的描述性分数，不依 Test 再选模型。

Test 前依次核对：完整 5000 步训练和正式 Val450、训练源码与输入哈希、500 步检查点和头权重哈希、原 500 步 Val450；再用发布的 fix2 `run.py evaluate` 从**序列化 500 步检查点**重放 Val450，保存并重读预测。重放后的前景 mIoU 和四类 IoU 对原中间报告逐项相差不得超过 **0.02 个百分点**。超过就停止，不读取 Test。原中间 Val 报告不被改写，重放另存于 Test 结果目录的同级目录。

将本目录完整放在服务器 `/root/shared-nvme/BRIGHT-master/New/bright_test500_exploratory_v1/`，确认原发布的 `soft_memory_q_rebased_v1_fix2` 包仍在 `New/`。默认指向你已有的 `run_20261014_202057_full_fEYBZv7D`；若源运行换了，先设置 `BRIGHT_TRAIN_ROOT`。启动只需一行：

```bash
bash /root/shared-nvme/BRIGHT-master/New/bright_test500_exploratory_v1/start_server.sh
```

启动器立即打印后台 PID、日志、Test 目录和 Val500 重放目录。只有日志出现完整 Test878 终检后才能解释结果。若想只核查来源且**不读取 Test**：

```bash
/root/shared-nvme/conda-envs/bright4090/bin/python /root/shared-nvme/BRIGHT-master/New/bright_test500_exploratory_v1/test500.py plan --train-root /root/shared-nvme/BRIGHT-checkpoints/SRAC_SOFT_MEMORY_Q_REBASED_V1/run_20261014_202057_full_fEYBZv7D
```

结果 `result.json` 同时报告 Test 前景三类和 Test 四类 mIoU、各类 IoU、逐事件混淆矩阵，并写入 `exploratory: true`、`primary_endpoint: false`、`posthoc_checkpoint_selection: true`。`images.jsonl` 和 `predictions/*.npz` 保存每张图并在末尾重新读取。Test 需要标准 Test878 的四类真值；若数据集缺 Test 标注，工具会停止，不会声称 Test mIoU。不能用本轮 Test 分数重新挑检查点、调阈值或选择 A/B/C/D。

若本地没有 Torch，`test_test500.py` 可用桩模块执行纯协议合约测试；它不代表真实 CUDA/BRIGHT 验证。

## 过拟合线索审计（只读）

运行 `BRIGHT_PY=/root/shared-nvme/conda-envs/bright4090/bin/python`，然后：

```bash
"$BRIGHT_PY" /root/shared-nvme/BRIGHT-master/New/bright_test500_exploratory_v1/overfit_audit.py --train-root /root/shared-nvme/BRIGHT-checkpoints/SRAC_SOFT_MEMORY_Q_REBASED_V1/run_20261014_202057_full_fEYBZv7D
```

此命令只读取训练日志与 Val450 报告，不读取 Test、不加载权重。它不是严格的过拟合判定；要确认泛化差距，还需固定 Train 子集和相同评估方式，再重复种子。
